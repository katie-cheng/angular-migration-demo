import { Component, Input, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

class SparklineComponent {
    constructor() {
        this.values = [];
        this.stroke = '#003366';
    }
    get points() {
        const values = this.values.length ? this.values : [0];
        const max = Math.max(...values, 1);
        const step = 100 / Math.max(values.length - 1, 1);
        return values.map((value, index) => (index * step) + ',' + (30 - (value / max) * 30)).join(' ');
    }
}
SparklineComponent.decorators = [
    { type: Component, args: [{
                selector: 'nw-sparkline',
                template: '<svg viewBox="0 0 100 30" preserveAspectRatio="none" style="width:100%;height:30px"><polyline fill="none" [attr.stroke]="stroke" stroke-width="2" [attr.points]="points"></polyline></svg>'
            }] }
];
SparklineComponent.propDecorators = {
    values: [{ type: Input }],
    stroke: [{ type: Input }]
};

class LegacyChartsModule {
}
LegacyChartsModule.decorators = [
    { type: NgModule, args: [{
                declarations: [SparklineComponent],
                imports: [CommonModule],
                exports: [SparklineComponent]
            }] }
];

export { LegacyChartsModule, SparklineComponent };
