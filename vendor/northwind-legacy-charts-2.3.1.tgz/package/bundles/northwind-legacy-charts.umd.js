(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('@northwind/legacy-charts', ['exports', '@angular/core', '@angular/common'], factory) :
    (factory((global.northwind = global.northwind || {}, global.northwind['legacy-charts'] = {}), global.ng.core, global.ng.common));
}(this, (function (exports, core, common) { 'use strict';
    var SparklineComponent = /** @class */ (function () {
        function SparklineComponent() {
            this.values = [];
            this.stroke = '#003366';
        }
        return SparklineComponent;
    }());
    var LegacyChartsModule = /** @class */ (function () {
        function LegacyChartsModule() {
        }
        return LegacyChartsModule;
    }());
    exports.SparklineComponent = SparklineComponent;
    exports.LegacyChartsModule = LegacyChartsModule;
    Object.defineProperty(exports, '__esModule', { value: true });
})));
