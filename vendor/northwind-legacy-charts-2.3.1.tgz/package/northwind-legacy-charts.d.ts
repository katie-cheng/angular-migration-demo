export declare class SparklineComponent {
    values: number[];
    stroke: string;
    get points(): string;
}
export declare class LegacyChartsModule {
}
