# @northwind/legacy-charts

Sparkline and donut charts, built for the internal apps in 2019. Compiled
with View Engine; the publishing team was disbanded and the source was never
migrated to Ivy.
